﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '' disable the maximize box
        Me.MaximizeBox = False

        '' make it say copyright FLAMESNET 199X-2030
        Me.Text = "Copyright Flamesnet 199X-2030"
        '' make the background the same as the ultra 64 css
        Me.BackColor = Color.FromArgb(255, 255, 255)
        '' make the form borderless
        '' make it look like a 90s emulator
        Me.FormBorderStyle = FormBorderStyle.None
        '' make the form size the same as the ultra 64 css
        Me.Size = New Size(640, 480)
        '' make the form position the same as the ultra 64 css
        Me.StartPosition = FormStartPosition.CenterScreen
        '' make it resemble the ultrahle

        '' make the form transparent
        Me.TransparencyKey = Color.FromArgb(255, 255, 255)
        '' make the form not resizeable
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        '' make the form not resizeable



    End Sub
End Class
